package com.mahesh.livecricket

import kotlin.random.Random

enum class BallType { DOT, RUN1, RUN2, RUN3, FOUR, SIX, WICKET, WIDE, NOBALL }

enum class AnimKind(val ms: Int, val minor: Boolean = false) {
    FOUR(2200), SIX(2400), WICKET(2400), WIDE(1400), NOBALL(1500),
    FIFTY(2200), CENTURY(2600), WON(3200), LOST(2800),
    FREEHIT(1400, true), DOT(700, true), RUNS(800, true), OVER(1400, true)
}

data class Batter(
    val name: String,
    val runs: Int = 0,
    val balls: Int = 0,
    val fours: Int = 0,
    val sixes: Int = 0
)

data class Bowler(val name: String, val balls: Int = 0, val runs: Int = 0, val wickets: Int = 0)

data class BallEvent(
    val id: Long,
    val type: BallType,
    val label: String,
    val runsText: String,
    val anims: List<AnimKind>
)

data class DemoState(
    val runs: Int = 0,
    val wickets: Int = 0,
    val balls: Int = 0,
    val batters: List<Batter> = listOf(Batter("Batter A"), Batter("Batter B")),
    val strike: Int = 0,
    val nextBatter: Int = 2,
    val bowlers: List<Bowler> = listOf("A", "B", "C", "D", "E").map { Bowler("Bowler $it") },
    val bowlerIdx: Int = 0,
    val freeHit: Boolean = false,
    val timeline: List<BallEvent> = emptyList(),
    val commentary: List<String> = emptyList(),
    val last: BallEvent? = null,
    val finished: Boolean = false,
    val result: String = ""
)

object DemoEngine {
    const val MAX_OVERS = 10
    const val TARGET = 96
    const val TOTAL_BALLS = MAX_OVERS * 6

    fun overText(balls: Int): String = "${balls / 6}.${balls % 6}"

    fun randomBall(): BallType {
        val r = Random.nextInt(100)
        return when {
            r < 25 -> BallType.DOT
            r < 55 -> BallType.RUN1
            r < 63 -> BallType.RUN2
            r < 64 -> BallType.RUN3
            r < 78 -> BallType.FOUR
            r < 87 -> BallType.SIX
            r < 93 -> BallType.WICKET
            r < 98 -> BallType.WIDE
            else -> BallType.NOBALL
        }
    }

    private fun pick(vararg options: String): String = options[Random.nextInt(options.size)]

    fun apply(s: DemoState, input: BallType): DemoState {
        if (s.finished) return s

        // Free hit: batter cannot be out
        val t = if (input == BallType.WICKET && s.freeHit) BallType.DOT else input
        val legal = t != BallType.WIDE && t != BallType.NOBALL
        val bat = when (t) {
            BallType.RUN1 -> 1
            BallType.RUN2 -> 2
            BallType.RUN3 -> 3
            BallType.FOUR -> 4
            BallType.SIX -> 6
            else -> 0
        }
        val extra = if (legal) 0 else 1

        val batters = s.batters.toMutableList()
        val bowlers = s.bowlers.toMutableList()
        var strike = s.strike
        var wk = s.wickets
        var nextBatter = s.nextBatter
        val facer = batters[strike]
        val bowler = bowlers[s.bowlerIdx]
        val ballNo = "${s.balls / 6}.${s.balls % 6 + 1}"

        val updated = facer.copy(
            runs = facer.runs + bat,
            balls = facer.balls + (if (t == BallType.WIDE) 0 else 1),
            fours = facer.fours + (if (t == BallType.FOUR) 1 else 0),
            sixes = facer.sixes + (if (t == BallType.SIX) 1 else 0)
        )
        batters[strike] = updated
        bowlers[s.bowlerIdx] = bowler.copy(
            balls = bowler.balls + (if (legal) 1 else 0),
            runs = bowler.runs + bat + extra,
            wickets = bowler.wickets + (if (t == BallType.WICKET) 1 else 0)
        )

        if (t == BallType.WICKET) {
            wk++
            if (wk < 10) {
                batters[strike] = Batter("Batter ${'A' + nextBatter}")
                nextBatter++
            }
        }

        if (bat % 2 == 1) strike = 1 - strike
        val newBalls = s.balls + (if (legal) 1 else 0)
        val overDone = legal && newBalls % 6 == 0
        if (overDone) strike = 1 - strike
        val newRuns = s.runs + bat + extra
        val freeHit = t == BallType.NOBALL || (s.freeHit && t == BallType.WIDE)

        // Animations for this ball (decided from the real ball type, not from total runs)
        val anims = mutableListOf<AnimKind>()
        when (t) {
            BallType.FOUR -> anims += AnimKind.FOUR
            BallType.SIX -> anims += AnimKind.SIX
            BallType.WICKET -> anims += AnimKind.WICKET
            BallType.WIDE -> anims += AnimKind.WIDE
            BallType.NOBALL -> {
                anims += AnimKind.NOBALL
                anims += AnimKind.FREEHIT
            }
            BallType.DOT -> anims += AnimKind.DOT
            else -> anims += AnimKind.RUNS
        }
        if (facer.runs < 50 && updated.runs >= 50 && updated.runs < 100) anims += AnimKind.FIFTY
        if (facer.runs < 100 && updated.runs >= 100) anims += AnimKind.CENTURY

        var finished = false
        var result = ""
        if (newRuns >= TARGET) {
            finished = true
            result = "INDIA won by ${10 - wk} wickets"
            anims += AnimKind.WON
        } else if (wk >= 10 || newBalls >= TOTAL_BALLS) {
            finished = true
            result = if (newRuns == TARGET - 1) "Match tied"
            else "AUSTRALIA won by ${TARGET - 1 - newRuns} runs"
            anims += AnimKind.LOST
        }
        if (!finished && overDone) anims += AnimKind.OVER

        val text = when (t) {
            BallType.DOT -> pick("defended solidly.", "beaten outside off stump!", "left alone, dot ball.")
            BallType.RUN1 -> pick("pushed into the gap for a single.", "worked to mid-wicket, single taken.", "quick single to cover.")
            BallType.RUN2 -> pick("driven into the deep, they come back for two.", "placed well, two runs.")
            BallType.RUN3 -> "great running between the wickets, three runs!"
            BallType.FOUR -> pick("FOUR! Beautiful cover drive.", "FOUR! Cracked through point.", "FOUR! Timed to perfection past mid-off.")
            BallType.SIX -> pick("SIX! Smashed over long-on.", "SIX! Massive hit into the stands.", "SIX! Picks the length and launches it.")
            BallType.WICKET -> pick("OUT! Clean bowled!", "OUT! Caught at deep mid-wicket!", "OUT! Trapped LBW!")
            BallType.WIDE -> "wide ball, one extra."
            BallType.NOBALL -> "NO BALL! Free hit coming up."
        }
        var line = "$ballNo - ${bowler.name} to ${facer.name}: $text"
        if (input == BallType.WICKET && s.freeHit) line += " (Free hit, batter cannot be out)"
        val lines = mutableListOf(line)
        if (overDone && !finished) lines.add(0, "Over ${newBalls / 6} complete: $newRuns/$wk")
        if (finished) lines.add(0, "RESULT: $result")

        val label = when (t) {
            BallType.DOT -> "0"
            BallType.RUN1 -> "1"
            BallType.RUN2 -> "2"
            BallType.RUN3 -> "3"
            BallType.FOUR -> "4"
            BallType.SIX -> "6"
            BallType.WICKET -> "W"
            BallType.WIDE -> "Wd"
            BallType.NOBALL -> "Nb"
        }
        val runsText = when (t) {
            BallType.RUN1 -> "+1 RUN"
            BallType.RUN2 -> "+2 RUNS"
            BallType.RUN3 -> "+3 RUNS"
            BallType.FOUR -> "+4 RUNS"
            BallType.SIX -> "+6 RUNS"
            BallType.WIDE, BallType.NOBALL -> "+1 EXTRA"
            else -> ""
        }
        val ev = BallEvent(System.nanoTime(), t, label, runsText, anims)

        return s.copy(
            runs = newRuns,
            wickets = wk,
            balls = newBalls,
            batters = batters,
            strike = strike,
            nextBatter = nextBatter,
            bowlers = bowlers,
            bowlerIdx = if (overDone) (s.bowlerIdx + 1) % bowlers.size else s.bowlerIdx,
            freeHit = freeHit,
            timeline = (s.timeline + ev).takeLast(60),
            commentary = (lines + s.commentary).take(40),
            last = ev,
            finished = finished,
            result = result
        )
    }
}
