package com.mahesh.livecricket

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class UiState(
    val matches: List<Match> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val hits: String = "",
    val lastUpdated: String = ""
)

class CricketViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("cricket", Context.MODE_PRIVATE)
    private val gson = Gson()

    var state by mutableStateOf(UiState())
        private set
    var apiKey by mutableStateOf(prefs.getString("key", "") ?: "")
        private set
    var intervalSec by mutableStateOf(prefs.getInt("interval", 300))
        private set
    var themeMode by mutableStateOf(prefs.getInt("theme", 0))
        private set

    var scorecard by mutableStateOf<ScorecardData?>(null)
        private set
    var scoreLoading by mutableStateOf(false)
        private set
    var scoreError by mutableStateOf<String?>(null)
        private set

    init {
        val json = prefs.getString("cache", null)
        if (json != null) {
            try {
                val type = object : TypeToken<List<Match>>() {}.type
                val list: List<Match> = gson.fromJson(json, type)
                state = state.copy(
                    matches = list,
                    lastUpdated = prefs.getString("time", "") ?: ""
                )
            } catch (e: Exception) {
            }
        }
    }

    fun saveKey(k: String) {
        val key = k.trim()
        prefs.edit().putString("key", key).apply()
        apiKey = key
    }

    fun saveInterval(sec: Int) {
        prefs.edit().putInt("interval", sec).apply()
        intervalSec = sec
    }

    fun saveTheme(mode: Int) {
        prefs.edit().putInt("theme", mode).apply()
        themeMode = mode
    }

    private fun hitsText(i: Info?): String =
        if (i?.hitsToday != null && i.hitsLimit != null) "${i.hitsToday}/${i.hitsLimit}" else ""

    private fun nowText(): String =
        SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())

    fun refresh() {
        if (apiKey.isBlank()) return
        viewModelScope.launch {
            state = state.copy(loading = true, error = null)
            try {
                val r = ApiClient.api.currentMatches(apiKey)
                if (r.status == "success") {
                    val list = r.data.orEmpty().distinctBy { it.id }
                    val t = nowText()
                    prefs.edit()
                        .putString("cache", gson.toJson(list))
                        .putString("time", t)
                        .apply()
                    state = state.copy(
                        matches = list,
                        loading = false,
                        hits = hitsText(r.info),
                        lastUpdated = t
                    )
                } else {
                    state = state.copy(loading = false, error = r.reason ?: "API error")
                }
            } catch (e: Exception) {
                state = state.copy(
                    loading = false,
                    error = "Network ya API problem: ${e.message}"
                )
            }
        }
    }

    fun loadScorecard(id: String) {
        if (apiKey.isBlank()) return
        viewModelScope.launch {
            scoreLoading = true
            scoreError = null
            try {
                val r = ApiClient.api.scorecard(apiKey, id)
                if (r.status == "success") {
                    scorecard = r.data
                    state = state.copy(hits = hitsText(r.info))
                } else {
                    scoreError = r.reason ?: "API error"
                }
            } catch (e: Exception) {
                scoreError = "Network ya API problem: ${e.message}"
            }
            scoreLoading = false
        }
    }

    fun clearScorecard() {
        scorecard = null
        scoreError = null
    }
}
