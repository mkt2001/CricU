package com.mahesh.livecricket

import com.google.gson.annotations.SerializedName

data class Info(val hitsToday: Int?, val hitsLimit: Int?)

data class MatchesResponse(
    val data: List<Match>?,
    val status: String?,
    val reason: String?,
    val info: Info?
)

data class Match(
    val id: String,
    val name: String?,
    val matchType: String?,
    val status: String?,
    val venue: String?,
    val date: String?,
    val dateTimeGMT: String?,
    val teams: List<String>?,
    val score: List<Score>?,
    val matchStarted: Boolean?,
    val matchEnded: Boolean?
)

data class Score(val r: Int?, val w: Int?, val o: Double?, val inning: String?)

data class ScorecardResponse(
    val data: ScorecardData?,
    val status: String?,
    val reason: String?,
    val info: Info?
)

data class ScorecardData(
    val id: String?,
    val name: String?,
    val status: String?,
    val venue: String?,
    val score: List<Score>?,
    val scorecard: List<Inning>?
)

data class Inning(
    val inning: String?,
    val batting: List<Batting>?,
    val bowling: List<Bowling>?
)

data class Player(val id: String?, val name: String?)

data class Batting(
    val batsman: Player?,
    @SerializedName("dismissal-text") val dismissalText: String?,
    val r: Int?,
    val b: Int?,
    @SerializedName("4s") val fours: Int?,
    @SerializedName("6s") val sixes: Int?,
    val sr: String?
)

data class Bowling(
    val bowler: Player?,
    val o: Double?,
    val m: Int?,
    val r: Int?,
    val w: Int?,
    val nb: Int?,
    val wd: Int?,
    val eco: String?
)
