package com.mahesh.livecricket

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay

@Composable
fun AppRoot(vm: CricketViewModel) {
    var selected by remember { mutableStateOf<Match?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var showDemo by remember { mutableStateOf(false) }

    if (showDemo) {
        BackHandler { showDemo = false }
        DemoScreen(onBack = { showDemo = false })
        return
    }

    if (vm.apiKey.isBlank()) {
        KeyScreen(vm, onDemo = { showDemo = true })
        return
    }

    BackHandler(enabled = selected != null) { selected = null }

    val m = selected
    if (m == null) {
        HomeScreen(vm, onOpen = { selected = it }, onSettings = { showSettings = true }, onDemo = { showDemo = true })
    } else {
        DetailScreen(vm, m, onBack = { selected = null })
    }
    if (showSettings) SettingsDialog(vm) { showSettings = false }
}

@Composable
fun KeyScreen(vm: CricketViewModel, onDemo: () -> Unit) {
    var text by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Live Cricket", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("cricketdata.org wali API key yaha paste karein. Key sirf aapke phone me save hogi.")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("API key") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.saveKey(text) },
            enabled = text.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save & Start") }
        TextButton(onClick = onDemo, modifier = Modifier.fillMaxWidth()) {
            Text("Demo Match try karein (bina API key)")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: CricketViewModel, onOpen: (Match) -> Unit, onSettings: () -> Unit, onDemo: () -> Unit) {
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(vm.apiKey, vm.intervalSec) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                vm.refresh()
                delay(vm.intervalSec * 1000L)
            }
        }
    }

    var tab by remember { mutableIntStateOf(0) }
    val all = vm.state.matches
    val live = all.filter { it.matchStarted == true && it.matchEnded != true }
    val upcoming = all.filter { it.matchStarted != true }
    val recent = all.filter { it.matchEnded == true }
    val lists = listOf(live, upcoming, recent)
    val titles = listOf("Live", "Upcoming", "Recent")
    val list = lists[tab]

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Live Cricket") },
                actions = {
                    IconButton(onClick = onDemo) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Demo Match")
                    }
                    IconButton(onClick = { vm.refresh() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                titles.forEachIndexed { i, t ->
                    Tab(
                        selected = tab == i,
                        onClick = { tab = i },
                        text = { Text("$t (${lists[i].size})") }
                    )
                }
            }
            if (vm.state.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            vm.state.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp))
            }
            val footer = buildString {
                if (vm.state.lastUpdated.isNotEmpty()) append("Updated: ${vm.state.lastUpdated}")
                if (vm.state.hits.isNotEmpty()) append("  |  API hits: ${vm.state.hits}")
            }
            if (footer.isNotEmpty()) {
                Text(footer, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
            }
            if (list.isEmpty() && !vm.state.loading) {
                Text("Is category me abhi koi match nahi hai.", modifier = Modifier.padding(16.dp))
            }
            LazyColumn(
                Modifier.padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(list, key = { it.id }) { m -> MatchCard(m) { onOpen(m) } }
            }
        }
    }
}

@Composable
fun MatchCard(m: Match, onClick: () -> Unit) {
    val live = m.matchStarted == true && m.matchEnded != true
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (live) {
                    Text("● LIVE", color = Color(0xFFD32F2F), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.width(8.dp))
                }
                Text(m.matchType?.uppercase() ?: "", fontSize = 12.sp)
            }
            Text(m.name ?: "", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            m.venue?.let { Text(it, fontSize = 12.sp) }
            Spacer(Modifier.height(6.dp))
            m.score.orEmpty().forEach { s ->
                Text("${s.inning ?: ""}: ${s.r ?: 0}/${s.w ?: 0} (${s.o ?: 0} ov)", fontSize = 14.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text(m.status ?: "", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(vm: CricketViewModel, m: Match, onBack: () -> Unit) {
    val owner = LocalLifecycleOwner.current
    val isLive = m.matchStarted == true && m.matchEnded != true

    LaunchedEffect(m.id, vm.intervalSec) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            vm.loadScorecard(m.id)
            while (isLive) {
                delay(vm.intervalSec * 1000L)
                vm.loadScorecard(m.id)
            }
        }
    }
    DisposableEffect(m.id) { onDispose { vm.clearScorecard() } }

    val sc = vm.scorecard
    val header = if (sc != null) m.copy(score = sc.score ?: m.score, status = sc.status ?: m.status) else m
    val innings = sc?.scorecard.orEmpty()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(m.name ?: "Match", maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { vm.loadScorecard(m.id) }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                }
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { MatchCard(header) {} }
            if (vm.scoreLoading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            vm.scoreError?.let { e ->
                item { Text(e, color = MaterialTheme.colorScheme.error) }
            }
            if (!vm.scoreLoading && vm.scoreError == null && innings.isEmpty()) {
                item { Text("Is match ka detailed scorecard abhi available nahi hai.") }
            }
            items(innings) { inn -> InningBlock(inn) }
        }
    }
}

@Composable
fun InningBlock(inn: Inning) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(inn.inning ?: "Innings", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            StatRow(listOf("Batter", "R", "B", "4s", "6s", "SR"), bold = true)
            inn.batting.orEmpty().forEach { b ->
                Column(Modifier.padding(vertical = 3.dp)) {
                    StatRow(
                        listOf(
                            b.batsman?.name ?: "",
                            "${b.r ?: 0}", "${b.b ?: 0}",
                            "${b.fours ?: 0}", "${b.sixes ?: 0}",
                            b.sr ?: "-"
                        )
                    )
                    Text(b.dismissalText ?: "", fontSize = 11.sp, color = Color.Gray)
                }
            }
            Spacer(Modifier.height(10.dp))
            StatRow(listOf("Bowler", "O", "M", "R", "W", "Eco"), bold = true)
            inn.bowling.orEmpty().forEach { w ->
                StatRow(
                    listOf(
                        w.bowler?.name ?: "",
                        "${w.o ?: 0}", "${w.m ?: 0}", "${w.r ?: 0}", "${w.w ?: 0}",
                        w.eco ?: "-"
                    )
                )
            }
        }
    }
}

@Composable
fun StatRow(cells: List<String>, bold: Boolean = false) {
    val weights = listOf(3.2f, 0.9f, 0.9f, 0.9f, 0.9f, 1.4f)
    Row(Modifier.fillMaxWidth()) {
        cells.forEachIndexed { i, c ->
            Text(
                c,
                modifier = Modifier.weight(weights[i]),
                fontSize = 12.sp,
                fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
fun SettingsDialog(vm: CricketViewModel, onClose: () -> Unit) {
    var key by remember { mutableStateOf(vm.apiKey) }
    var sec by remember { mutableIntStateOf(vm.intervalSec) }
    var theme by remember { mutableIntStateOf(vm.themeMode) }
    val options = listOf(60 to "1 min", 120 to "2 min", 300 to "5 min", 600 to "10 min", 900 to "15 min")

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Settings") },
        confirmButton = {
            TextButton(onClick = {
                if (key.isNotBlank()) vm.saveKey(key)
                vm.saveInterval(sec)
                vm.saveTheme(theme)
                onClose()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    label = { Text("API key") },
                    singleLine = true
                )
                Spacer(Modifier.height(12.dp))
                Text("Auto refresh interval", fontWeight = FontWeight.SemiBold)
                options.forEach { (v, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { sec = v },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = sec == v, onClick = { sec = v })
                        Text(label)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Theme", fontWeight = FontWeight.SemiBold)
                listOf(0 to "System", 1 to "Light", 2 to "Dark", 3 to "AMOLED Black").forEach { (v, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { theme = v },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = theme == v, onClick = { theme = v })
                        Text(label)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Free plan me roz lagbhag 100 requests milti hain. Chhota interval = limit jaldi khatam.",
                    fontSize = 12.sp
                )
            }
        }
    )
}
