package com.mahesh.livecricket

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface CricApi {
    @GET("currentMatches")
    suspend fun currentMatches(
        @Query("apikey") key: String,
        @Query("offset") offset: Int = 0
    ): MatchesResponse

    @GET("match_scorecard")
    suspend fun scorecard(
        @Query("apikey") key: String,
        @Query("id") id: String
    ): ScorecardResponse
}

object ApiClient {
    val api: CricApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.cricapi.com/v1/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CricApi::class.java)
    }
}
