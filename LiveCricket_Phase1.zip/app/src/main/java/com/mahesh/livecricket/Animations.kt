package com.mahesh.livecricket

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

enum class Pose { WAVE, UP, FINGER, WIDE, NOBALL }

private val Gold = Color(0xFFFFC107)
private val Green = Color(0xFF2ECC71)
private val Red = Color(0xFFFF5252)
private val Orange = Color(0xFFFF9800)

@Composable
fun EventOverlay(event: BallEvent, result: String, onDone: () -> Unit) {
    var index by remember(event.id) { mutableIntStateOf(0) }
    val kind = event.anims[index]
    val progress = remember(event.id, index) { Animatable(0f) }

    LaunchedEffect(event.id, index) {
        progress.animateTo(1f, tween(kind.ms, easing = LinearEasing))
        if (index + 1 < event.anims.size) index++ else onDone()
    }

    val p = progress.value
    val fade = when {
        p < 0.1f -> p / 0.1f
        p > 0.9f -> (1f - p) / 0.1f
        else -> 1f
    }

    if (kind.minor) {
        val text = when (kind) {
            AnimKind.DOT -> "DOT BALL"
            AnimKind.RUNS -> event.runsText
            AnimKind.OVER -> "OVER COMPLETE"
            else -> "FREE HIT!"
        }
        Box(
            Modifier.fillMaxSize().padding(top = 90.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            Text(
                text,
                color = if (kind == AnimKind.FREEHIT) Gold else Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier
                    .graphicsLayer { alpha = fade }
                    .background(Color(0xDD0D1B3E), RoundedCornerShape(24.dp))
                    .padding(horizontal = 24.dp, vertical = 10.dp)
            )
        }
        return
    }

    val title: String
    val sub: String
    val color: Color
    when (kind) {
        AnimKind.FOUR -> { title = "FOUR!"; sub = "+4 RUNS"; color = Green }
        AnimKind.SIX -> { title = "SIX!"; sub = "+6 RUNS"; color = Gold }
        AnimKind.WICKET -> { title = "WICKET!"; sub = "OUT"; color = Red }
        AnimKind.WIDE -> { title = "WIDE"; sub = "+1 EXTRA"; color = Orange }
        AnimKind.NOBALL -> { title = "NO BALL"; sub = "+1 EXTRA | FREE HIT NEXT"; color = Orange }
        AnimKind.FIFTY -> { title = "FIFTY!"; sub = "50 RUNS"; color = Gold }
        AnimKind.CENTURY -> { title = "CENTURY!"; sub = "100 RUNS"; color = Gold }
        AnimKind.WON -> { title = "MATCH WON!"; sub = result; color = Green }
        else -> { title = if (result == "Match tied") "MATCH TIED" else "MATCH OVER"; sub = result; color = Orange }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.78f * fade)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(16.dp).graphicsLayer { alpha = fade }
        ) {
            Box(Modifier.fillMaxWidth().height(260.dp)) {
                when (kind) {
                    AnimKind.FOUR -> BoundaryScene(p, six = false)
                    AnimKind.SIX -> {
                        BoundaryScene(p, six = true)
                        Confetti(p, listOf(Gold, Color(0xFFFFE082), Color.White))
                    }
                    AnimKind.WICKET -> WicketScene(p)
                    AnimKind.WIDE -> UmpireFigure(Pose.WIDE, p, Modifier.fillMaxSize())
                    AnimKind.NOBALL -> UmpireFigure(Pose.NOBALL, p, Modifier.fillMaxSize())
                    AnimKind.FIFTY -> StarBurst(p, "50")
                    AnimKind.CENTURY -> StarBurst(p, "100")
                    AnimKind.WON -> {
                        Confetti(p, listOf(Gold, Green, Color.White, Color(0xFF42A5F5)))
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("\uD83C\uDFC6", fontSize = 90.sp)
                        }
                    }
                    else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("\uD83C\uDFCF", fontSize = 90.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            BigLabel(title, sub, color, p)
        }
    }
}

@Composable
fun BigLabel(title: String, sub: String, color: Color, p: Float) {
    val s = 0.5f + 0.5f * (p / 0.25f).coerceAtMost(1f) + 0.03f * sin(p * 20f)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.graphicsLayer { scaleX = s; scaleY = s }
    ) {
        Text(
            title,
            color = color,
            fontSize = 54.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center
        )
        Text(
            sub,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun BoundaryScene(p: Float, six: Boolean) {
    Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.weight(1.7f).fillMaxHeight()) {
            val w = size.width
            val h = size.height
            drawOval(Color(0xFF1B5E20), topLeft = Offset(0f, h * 0.1f), size = Size(w, h * 0.8f))
            drawOval(
                Color.White.copy(alpha = 0.85f),
                topLeft = Offset(w * 0.02f, h * 0.14f),
                size = Size(w * 0.96f, h * 0.72f),
                style = Stroke(width = h * 0.015f)
            )
            drawRect(Color(0xFFD7B98E), topLeft = Offset(w * 0.46f, h * 0.32f), size = Size(w * 0.08f, h * 0.36f))

            val start = Offset(w * 0.5f, h * 0.5f)
            val end = if (six) Offset(w * 0.97f, h * 0.05f) else Offset(w * 0.96f, h * 0.66f)
            fun pos(q: Float): Offset {
                val x = start.x + (end.x - start.x) * q
                var y = start.y + (end.y - start.y) * q
                if (six) y -= h * 0.3f * 4f * q * (1f - q)
                return Offset(x, y)
            }
            val q = (p / 0.6f).coerceIn(0f, 1f)
            for (k in 4 downTo 1) {
                val qq = (q - 0.04f * k).coerceAtLeast(0f)
                drawCircle(Color.White.copy(alpha = 0.12f * (5 - k)), radius = h * 0.03f, center = pos(qq))
            }
            val rad = h * 0.04f * (if (six) 1f - 0.5f * q else 1f)
            drawCircle(Color.White, radius = rad, center = pos(q))
        }
        Box(Modifier.weight(1f).fillMaxHeight()) {
            if (p > 0.45f) {
                UmpireFigure(if (six) Pose.UP else Pose.WAVE, p, Modifier.fillMaxSize())
            }
        }
    }
}

@Composable
fun WicketScene(p: Float) {
    Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.weight(1.5f).fillMaxHeight()) {
            val w = size.width
            val h = size.height
            val baseY = h * 0.9f
            val top = h * 0.4f
            val xs = listOf(w * 0.40f, w * 0.50f, w * 0.60f)
            val hit = ((p - 0.5f) / 0.5f).coerceIn(0f, 1f)
            val stump = Color(0xFFFFE0B2)

            xs.forEachIndexed { i, x ->
                val deg = hit * ((i - 1) * 55f + (if (i == 1) 25f else 0f))
                rotate(degrees = deg, pivot = Offset(x, baseY)) {
                    drawLine(stump, Offset(x, baseY), Offset(x, top), h * 0.03f, StrokeCap.Round)
                }
            }
            // bails fly up
            val bailY = top - hit * h * 0.35f
            val bailAlpha = 1f - hit * 0.7f
            rotate(degrees = hit * 200f, pivot = Offset(xs[0] + w * 0.05f, bailY)) {
                drawLine(stump.copy(alpha = bailAlpha), Offset(xs[0], bailY), Offset(xs[1], bailY), h * 0.02f, StrokeCap.Round)
            }
            rotate(degrees = -hit * 200f, pivot = Offset(xs[1] + w * 0.05f, bailY)) {
                drawLine(stump.copy(alpha = bailAlpha), Offset(xs[1], bailY), Offset(xs[2], bailY), h * 0.02f, StrokeCap.Round)
            }
            // ball
            val bx = w * 0.05f + (w * 0.9f) * p
            drawCircle(Color.White, radius = h * 0.04f, center = Offset(bx, h * 0.6f))
        }
        Box(Modifier.weight(1f).fillMaxHeight()) {
            if (p > 0.5f) UmpireFigure(Pose.FINGER, p, Modifier.fillMaxSize())
        }
    }
}

@Composable
fun StarBurst(p: Float, label: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val h = size.height
            for (i in 0 until 14) {
                val a = (i * 360f / 14f + p * 80f) * PI.toFloat() / 180f
                val r0 = h * 0.12f
                val r1 = h * (0.15f + 0.35f * p)
                drawLine(
                    Gold.copy(alpha = 1f - p * 0.5f),
                    Offset(c.x + r0 * cos(a), c.y + r0 * sin(a)),
                    Offset(c.x + r1 * cos(a), c.y + r1 * sin(a)),
                    h * 0.02f,
                    StrokeCap.Round
                )
            }
        }
        Confetti(p, listOf(Gold, Color.White, Color(0xFFFFE082)))
        Text(label, color = Gold, fontSize = 72.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun Confetti(p: Float, colors: List<Color>) {
    val seeds = remember { List(45) { Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat()) } }
    Canvas(Modifier.fillMaxSize()) {
        seeds.forEachIndexed { i, s ->
            val y = ((s.second * 0.4f + p * (0.5f + s.third * 0.9f)) % 1.2f) * size.height
            val x = s.first * size.width + size.width * 0.02f * sin(p * 10f + i)
            drawCircle(
                colors[i % colors.size],
                radius = size.height * (0.012f + s.third * 0.02f),
                center = Offset(x, y)
            )
        }
    }
}

private fun DrawScope.drawArm(from: Offset, angleDeg: Float, len: Float, sw: Float, skin: Color): Offset {
    val rad = angleDeg * PI.toFloat() / 180f
    val to = Offset(from.x + len * cos(rad), from.y + len * sin(rad))
    drawLine(Color.White, from, to, sw, StrokeCap.Round)
    drawCircle(skin, radius = sw * 0.9f, center = to)
    return to
}

@Composable
fun UmpireFigure(pose: Pose, t: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val sw = h * 0.035f
        val shoulderY = h * 0.30f
        val hipY = h * 0.62f
        val phase = t * 2f * PI.toFloat() * 4f
        val skin = Color(0xFFFFCC80)

        // legs, torso, head
        drawLine(Color(0xFF90A4AE), Offset(cx, hipY), Offset(cx - w * 0.10f, h * 0.97f), sw * 1.5f, StrokeCap.Round)
        drawLine(Color(0xFF90A4AE), Offset(cx, hipY), Offset(cx + w * 0.10f, h * 0.97f), sw * 1.5f, StrokeCap.Round)
        drawLine(Color.White, Offset(cx, shoulderY), Offset(cx, hipY), sw * 2.4f, StrokeCap.Round)
        drawCircle(skin, radius = h * 0.085f, center = Offset(cx, h * 0.17f))

        // arm angles: 0 = right, 90 = down, -90 = up. Left arm is mirrored (180 - angle).
        var ar = 0f
        var al = 0f
        when (pose) {
            Pose.WAVE -> {
                ar = 75f + 50f * sin(phase)
                al = 180f - (75f + 50f * sin(phase + PI.toFloat()))
            }
            Pose.UP -> {
                val a = -65f + 8f * sin(phase * 0.5f)
                ar = a
                al = 180f - a
            }
            Pose.FINGER -> {
                ar = -85f
                al = 180f - 75f
            }
            Pose.WIDE -> {
                ar = 4f * sin(phase)
                al = 180f - 4f * sin(phase)
            }
            Pose.NOBALL -> {
                ar = 0f
                al = 180f - 75f
            }
        }

        val armLen = h * 0.30f
        val rHand = drawArm(Offset(cx + w * 0.03f, shoulderY + sw), ar, armLen, sw, skin)
        drawArm(Offset(cx - w * 0.03f, shoulderY + sw), al, armLen, sw, skin)
        if (pose == Pose.FINGER) {
            drawLine(skin, rHand, Offset(rHand.x, rHand.y - h * 0.09f), sw * 0.8f, StrokeCap.Round)
        }
    }
}
