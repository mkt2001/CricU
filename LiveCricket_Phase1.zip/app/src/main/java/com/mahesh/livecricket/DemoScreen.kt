package com.mahesh.livecricket

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DemoScreen(onBack: () -> Unit) {
    var state by remember { mutableStateOf(DemoState()) }
    var overlay by remember { mutableStateOf<BallEvent?>(null) }
    var auto by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current

    fun play(t: BallType) {
        if (state.finished || overlay != null) return
        val next = DemoEngine.apply(state, t)
        state = next
        val ev = next.last
        if (ev != null && ev.anims.isNotEmpty()) {
            overlay = ev
            val strong = ev.anims.any {
                it == AnimKind.FOUR || it == AnimKind.SIX || it == AnimKind.WICKET
            }
            if (strong) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }

    LaunchedEffect(auto) {
        while (auto && !state.finished) {
            while (overlay != null) delay(100)
            delay(900)
            play(DemoEngine.randomBall())
        }
        if (state.finished) auto = false
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Demo Match") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        ) { pad ->
            LazyColumn(
                Modifier.padding(pad).padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { ScoreBoard(state) }
                item { BatterCard(state) }
                item { TimelineCard(state) }
                item {
                    Controls(
                        auto = auto,
                        onAuto = { auto = it },
                        enabled = overlay == null && !state.finished,
                        onBall = { play(it) },
                        onReset = {
                            state = DemoState()
                            overlay = null
                            auto = false
                        }
                    )
                }
                item { Text("Live Commentary", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                items(state.commentary.take(12)) { line -> Text(line, fontSize = 13.sp) }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
        overlay?.let { ev ->
            EventOverlay(ev, state.result) { overlay = null }
        }
    }
}

@Composable
fun StadiumHeader() {
    Canvas(Modifier.fillMaxWidth().height(90.dp)) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF050B1F), Color(0xFF123A6B))))
        listOf(0.12f, 0.88f).forEach { fx ->
            val c = Offset(size.width * fx, size.height * 0.2f)
            drawCircle(
                Brush.radialGradient(listOf(Color(0x99FFF8E1), Color.Transparent), center = c, radius = size.height * 0.8f),
                radius = size.height * 0.8f,
                center = c
            )
        }
        drawOval(
            Color(0xFF1B7A3A),
            topLeft = Offset(-size.width * 0.2f, size.height * 0.55f),
            size = Size(size.width * 1.4f, size.height * 1.2f)
        )
        drawRect(
            Color(0xFFD7B98E),
            topLeft = Offset(size.width * 0.46f, size.height * 0.62f),
            size = Size(size.width * 0.08f, size.height * 0.38f)
        )
    }
}

@Composable
fun ScoreBoard(s: DemoState) {
    val runsAnim by animateIntAsState(s.runs, tween(600), label = "runs")
    val wkAnim by animateIntAsState(s.wickets, tween(300), label = "wk")
    val pulse by rememberInfiniteTransition(label = "live").animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "pulse"
    )
    val ballsLeft = DemoEngine.TOTAL_BALLS - s.balls
    val need = DemoEngine.TARGET - s.runs
    val crr = if (s.balls > 0) s.runs * 6f / s.balls else 0f
    val rrr = if (ballsLeft > 0) need.coerceAtLeast(0) * 6f / ballsLeft else 0f

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B3E))
    ) {
        Column {
            StadiumHeader()
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (s.finished) "COMPLETED" else "\u25CF LIVE",
                        color = Color(0xFFFF5252).copy(alpha = if (s.finished) 1f else pulse),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("DEMO T10 | MATCH 1", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
                Spacer(Modifier.height(4.dp))
                Text("INDIA vs AUSTRALIA", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("INDIA", color = Color(0xFF90CAF9), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(Modifier.width(14.dp))
                    Text(
                        "$runsAnim/$wkAnim",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 52.sp
                    )
                }
                Text(
                    "Overs: ${DemoEngine.overText(s.balls)}/${DemoEngine.MAX_OVERS}",
                    color = Color.White,
                    fontSize = 14.sp
                )
                Text(
                    "CRR ${String.format(Locale.US, "%.2f", crr)}  |  RRR ${String.format(Locale.US, "%.2f", rrr)}",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 13.sp
                )
                Text(
                    if (s.finished) s.result
                    else "Target ${DemoEngine.TARGET} | Need ${need.coerceAtLeast(0)} from $ballsLeft balls",
                    color = Color(0xFFFFC107),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                if (s.freeHit && !s.finished) {
                    Text("FREE HIT", color = Color(0xFFFFC107), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun BatterCard(s: DemoState) {
    val bw = s.bowlers[s.bowlerIdx]
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            StatRow(listOf("Batter", "R", "B", "4s", "6s", "SR"), bold = true)
            s.batters.forEachIndexed { i, b ->
                val sr = if (b.balls > 0) String.format(Locale.US, "%.1f", b.runs * 100f / b.balls) else "-"
                StatRow(
                    listOf(
                        b.name + if (i == s.strike) "*" else "",
                        "${b.runs}", "${b.balls}", "${b.fours}", "${b.sixes}", sr
                    )
                )
            }
            Spacer(Modifier.height(8.dp))
            StatRow(listOf("Bowler", "O", "M", "R", "W", "Eco"), bold = true)
            val eco = if (bw.balls > 0) String.format(Locale.US, "%.1f", bw.runs * 6f / bw.balls) else "-"
            StatRow(listOf(bw.name, DemoEngine.overText(bw.balls), "0", "${bw.runs}", "${bw.wickets}", eco))
        }
    }
}

private fun chipColor(t: BallType): Color = when (t) {
    BallType.DOT -> Color(0xFF616161)
    BallType.RUN1, BallType.RUN2, BallType.RUN3 -> Color(0xFF1976D2)
    BallType.FOUR -> Color(0xFF2E7D32)
    BallType.SIX -> Color(0xFFF9A825)
    BallType.WICKET -> Color(0xFFD32F2F)
    BallType.WIDE, BallType.NOBALL -> Color(0xFFEF6C00)
}

@Composable
fun TimelineCard(s: DemoState) {
    val recent = s.timeline.takeLast(12)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("Ball-by-ball", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            if (recent.isEmpty()) {
                Text("Abhi koi gend nahi hui. Next ball dabayein.", fontSize = 12.sp)
            } else {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    recent.forEachIndexed { i, e ->
                        val last = i == recent.lastIndex
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(chipColor(e.type))
                                .then(
                                    if (last) Modifier.border(2.dp, Color(0xFFFFD54F), CircleShape)
                                    else Modifier
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(e.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Controls(
    auto: Boolean,
    onAuto: (Boolean) -> Unit,
    enabled: Boolean,
    onBall: (BallType) -> Unit,
    onReset: () -> Unit
) {
    val row1 = listOf(
        "0" to BallType.DOT, "1" to BallType.RUN1, "2" to BallType.RUN2,
        "3" to BallType.RUN3, "4" to BallType.FOUR
    )
    val row2 = listOf(
        "6" to BallType.SIX, "W" to BallType.WICKET, "Wd" to BallType.WIDE, "Nb" to BallType.NOBALL
    )
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Auto play", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(8.dp))
                Switch(checked = auto, onCheckedChange = onAuto)
                Spacer(Modifier.weight(1f))
                OutlinedButton(onClick = onReset) { Text("Reset") }
            }
            Button(
                onClick = { onBall(DemoEngine.randomBall()) },
                enabled = enabled,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Next ball (random)") }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row1.forEach { (label, type) ->
                    OutlinedButton(
                        onClick = { onBall(type) },
                        enabled = enabled,
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(label) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row2.forEach { (label, type) ->
                    OutlinedButton(
                        onClick = { onBall(type) },
                        enabled = enabled,
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(label) }
                }
            }
        }
    }
}
